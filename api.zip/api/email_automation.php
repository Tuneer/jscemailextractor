<?php
// Email Automation Service - Automatic email capture and processing
require_once __DIR__ . '/db.php';

class EmailAutomationService {
    private $imapHost;
    private $imapUser;
    private $imapPassword;
    private $inbox;
    
    public function __construct() {
        global $email_config;
        $this->imapHost = $email_config['imap_host'];
        $this->imapUser = $email_config['imap_user'];
        $this->imapPassword = $email_config['imap_password'];
    }
    
    // Connect to IMAP server
    public function connect() {
        $this->inbox = @imap_open($this->imapHost, $this->imapUser, $this->imapPassword);
        return $this->inbox !== false;
    }
    
    // Disconnect from IMAP server
    public function disconnect() {
        if ($this->inbox) {
            imap_close($this->inbox);
            $this->inbox = null;
        }
    }
    
    // Fetch all unread emails
    public function fetchUnreadEmails($limit = 50) {
        if (!$this->inbox && !$this->connect()) {
            return ['success' => false, 'message' => 'IMAP connection failed', 'emails' => []];
        }
        
        $emails = imap_search($this->inbox, 'UNSEEN', SE_UID);
        if (!$emails) {
            return ['success' => true, 'message' => 'No unread emails', 'emails' => [], 'count' => 0];
        }
        
        rsort($emails);
        $results = [];
        $count = 0;
        
        foreach ($emails as $emailUid) {
            if ($count >= $limit) break;
            
            $emailData = $this->processEmail($emailUid);
            if ($emailData) {
                $results[] = $emailData;
                $count++;
            }
        }
        
        return ['success' => true, 'emails' => $results, 'count' => count($results)];
    }
    
    // Fetch emails from specific sender
    public function fetchEmailsFromSender($senderEmail, $limit = 50) {
        if (!$this->inbox && !$this->connect()) {
            return ['success' => false, 'message' => 'IMAP connection failed', 'emails' => []];
        }
        
        $searchCriteria = 'UNSEEN FROM "' . $senderEmail . '"';
        $emails = imap_search($this->inbox, $searchCriteria, SE_UID);
        
        if (!$emails) {
            return ['success' => true, 'message' => 'No emails from sender', 'emails' => [], 'count' => 0];
        }
        
        rsort($emails);
        $results = [];
        $count = 0;
        
        foreach ($emails as $emailUid) {
            if ($count >= $limit) break;
            
            $emailData = $this->processEmail($emailUid);
            if ($emailData) {
                $results[] = $emailData;
                $count++;
            }
        }
        
        return ['success' => true, 'emails' => $results, 'count' => count($results)];
    }
    
    // Fetch emails with attachments only
    public function fetchEmailsWithAttachments($limit = 50) {
        if (!$this->inbox && !$this->connect()) {
            return ['success' => false, 'message' => 'IMAP connection failed', 'emails' => []];
        }
        
        $emails = imap_search($this->inbox, 'UNSEEN', SE_UID);
        if (!$emails) {
            return ['success' => true, 'message' => 'No unread emails', 'emails' => [], 'count' => 0];
        }
        
        rsort($emails);
        $results = [];
        $count = 0;
        
        foreach ($emails as $emailUid) {
            if ($count >= $limit) break;
            
            $structure = imap_fetchstructure($this->inbox, $emailUid, FT_UID);
            if ($this->hasAttachments($structure)) {
                $emailData = $this->processEmail($emailUid);
                if ($emailData) {
                    $results[] = $emailData;
                    $count++;
                }
            }
        }
        
        return ['success' => true, 'emails' => $results, 'count' => count($results)];
    }
    
    // Check if email has attachments
    private function hasAttachments($structure) {
        if (isset($structure->parts)) {
            foreach ($structure->parts as $part) {
                if (($part->disposition ?? '') === 'ATTACHMENT' || ($part->disposition ?? '') === 'attachment') {
                    return true;
                }
                if (isset($part->parts)) {
                    if ($this->hasAttachments($part)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    // Process single email
    private function processEmail($emailUid) {
        $overview = imap_fetch_overview($this->inbox, $emailUid, FT_UID);
        if (!$overview || !isset($overview[0])) {
            return null;
        }
        
        $overview = $overview[0];
        $structure = imap_fetchstructure($this->inbox, $emailUid, FT_UID);
        
        // Get email body
        $body = $this->getEmailBody($emailUid, $structure);
        
        // Extract email data
        $emailData = [
            'uid' => $emailUid,
            'subject' => $this->decodeMimeString($overview->subject ?? ''),
            'from' => $this->decodeMimeString($overview->from ?? ''),
            'from_email' => $this->extractEmailAddress($overview->from ?? ''),
            'to' => $overview->to ?? '',
            'date' => date('Y-m-d H:i:s', strtotime($overview->date ?? 'now')),
            'body_text' => $body['text'] ?? '',
            'body_html' => $body['html'] ?? '',
            'attachments' => []
        ];
        
        // Process attachments
        if (isset($structure->parts)) {
            $emailData['attachments'] = $this->processAttachments($emailUid, $structure->parts);
        }
        
        // Save to database
        $savedEmail = $this->saveEmailToDatabase($emailData);
        $emailData['saved'] = $savedEmail;
        
        return $emailData;
    }
    
    // Get email body (text and HTML)
    private function getEmailBody($emailUid, $structure) {
        $body = ['text' => '', 'html' => ''];
        
        if (!isset($structure->parts)) {
            // Simple email, no multipart
            $content = imap_body($this->inbox, $emailUid, FT_UID | FT_PEEK);
            $body['text'] = $this->decodeContent($content, $structure->encoding ?? 0);
        } else {
            // Multipart email
            foreach ($structure->parts as $partNum => $part) {
                $disposition = strtolower($part->disposition ?? '');
                
                // Skip attachments
                if ($disposition === 'attachment') continue;
                
                $content = imap_fetchbody($this->inbox, $emailUid, $partNum + 1, FT_UID | FT_PEEK);
                $decoded = $this->decodeContent($content, $part->encoding ?? 0);
                
                $mimeType = $this->getMimeType($part);
                if ($mimeType === 'text/html') {
                    $body['html'] = $decoded;
                } elseif ($mimeType === 'text/plain' && empty($body['text'])) {
                    $body['text'] = $decoded;
                }
                
                // Handle nested parts
                if (isset($part->parts)) {
                    $nestedBody = $this->getEmailBodyFromParts($emailUid, $part->parts, $partNum + 1);
                    $body['text'] = $nestedBody['text'] ?: $body['text'];
                    $body['html'] = $nestedBody['html'] ?: $body['html'];
                }
            }
        }
        
        return $body;
    }
    
    // Get body from nested parts
    private function getEmailBodyFromParts($emailUid, $parts, $parentPartNum) {
        $body = ['text' => '', 'html' => ''];
        
        foreach ($parts as $subPartNum => $part) {
            $disposition = strtolower($part->disposition ?? '');
            if ($disposition === 'attachment') continue;
            
            $partNumber = $parentPartNum . '.' . ($subPartNum + 1);
            $content = imap_fetchbody($this->inbox, $emailUid, $partNumber, FT_UID | FT_PEEK);
            $decoded = $this->decodeContent($content, $part->encoding ?? 0);
            
            $mimeType = $this->getMimeType($part);
            if ($mimeType === 'text/html') {
                $body['html'] = $decoded;
            } elseif ($mimeType === 'text/plain') {
                $body['text'] = $decoded;
            }
        }
        
        return $body;
    }
    
    // Process attachments
    private function processAttachments($emailUid, $parts, $partNumPrefix = '') {
        $attachments = [];
        
        foreach ($parts as $index => $part) {
            $partNum = $partNumPrefix ? $partNumPrefix . '.' . ($index + 1) : ($index + 1);
            $disposition = strtolower($part->disposition ?? '');
            
            // Check if this is an attachment
            if ($disposition === 'attachment' || !empty($part->dparameters)) {
                $filename = $this->getAttachmentFilename($part);
                if ($filename) {
                    $content = imap_fetchbody($this->inbox, $emailUid, $partNum, FT_UID);
                    $decoded = $this->decodeContent($content, $part->encoding ?? 0);
                    
                    $attachmentData = [
                        'filename' => $filename,
                        'content_type' => $this->getMimeType($part),
                        'size' => strlen($decoded),
                        'data' => $decoded
                    ];
                    
                    // Save attachment to file
                    $savedPath = $this->saveAttachmentToFile($filename, $decoded);
                    $attachmentData['file_path'] = $savedPath;
                    
                    // Parse Excel if applicable
                    if ($this->isExcelFile($filename)) {
                        $attachmentData['excel_data'] = $this->parseExcelContent($decoded, $filename);
                    }
                    
                    $attachments[] = $attachmentData;
                }
            }
            
            // Handle nested parts
            if (isset($part->parts)) {
                $nestedAttachments = $this->processAttachments($emailUid, $part->parts, $partNum);
                $attachments = array_merge($attachments, $nestedAttachments);
            }
        }
        
        return $attachments;
    }
    
    // Get attachment filename
    private function getAttachmentFilename($part) {
        if (isset($part->dparameters)) {
            foreach ($part->dparameters as $param) {
                if (strtolower($param->attribute) === 'filename') {
                    return $this->decodeMimeString($param->value);
                }
            }
        }
        if (isset($part->parameters)) {
            foreach ($part->parameters as $param) {
                if (strtolower($param->attribute) === 'name') {
                    return $this->decodeMimeString($param->value);
                }
            }
        }
        return 'attachment_' . time();
    }
    
    // Get MIME type
    private function getMimeType($part) {
        $types = [
            0 => 'text', 1 => 'multipart', 2 => 'message', 3 => 'application',
            4 => 'audio', 5 => 'image', 6 => 'video', 7 => 'other'
        ];
        $subtypes = [
            0 => 'unknown', 1 => 'plain', 2 => 'html', 3 => 'enriched',
            4 => 'richtext', 5 => 'rtf', 6 => 'xml', 7 => 'csv',
            8 => 'json', 9 => 'pdf', 10 => 'zip', 11 => 'x-gzip',
            12 => 'x-tar', 13 => 'vnd.ms-excel', 14 => 'vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        ];
        
        $type = $types[$part->type ?? 0] ?? 'application';
        $subtype = strtolower($part->subtype ?? 'octet-stream');
        
        return $type . '/' . $subtype;
    }
    
    // Decode content based on encoding
    private function decodeContent($content, $encoding) {
        switch ($encoding) {
            case 0: // 7BIT
            case 1: // 8BIT
            case 2: // BINARY
                return $content;
            case 3: // BASE64
                return base64_decode($content);
            case 4: // QUOTED-PRINTABLE
                return quoted_printable_decode($content);
            default:
                return $content;
        }
    }
    
    // Decode MIME encoded string
    private function decodeMimeString($string) {
        if (empty($string)) return '';
        $decoded = imap_mime_header_decode($string);
        $result = '';
        foreach ($decoded as $part) {
            $result .= $part->text;
        }
        return $result;
    }
    
    // Extract email address from string
    private function extractEmailAddress($from) {
        if (preg_match('/<([^>]+)>/', $from, $matches)) {
            return $matches[1];
        }
        return $from;
    }
    
    // Save attachment to file
    private function saveAttachmentToFile($filename, $content) {
        $uploadDir = __DIR__ . '/attachments/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        
        $safeFilename = preg_replace('/[^a-zA-Z0-9._-]/', '_', $filename);
        $filePath = $uploadDir . time() . '_' . $safeFilename;
        file_put_contents($filePath, $content);
        
        return $filePath;
    }
    
    // Check if file is Excel
    private function isExcelFile($filename) {
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        return in_array($ext, ['xlsx', 'xls', 'csv']);
    }
    
    // Parse Excel content (basic CSV parsing)
    private function parseExcelContent($content, $filename) {
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        
        if ($ext === 'csv') {
            return $this->parseCSV($content);
        }
        
        // For xlsx/xls, we'd need PhpSpreadsheet library
        // Return raw content for now - install PhpSpreadsheet for full Excel support
        return ['raw_content' => true, 'message' => 'Excel parsing requires PhpSpreadsheet library'];
    }
    
    // Parse CSV content
    private function parseCSV($content) {
        $lines = explode("\n", $content);
        $data = [];
        $headers = [];
        
        foreach ($lines as $index => $line) {
            if (empty(trim($line))) continue;
            
            $row = str_getcsv($line);
            if ($index === 0) {
                $headers = $row;
            } else {
                if (count($headers) === count($row)) {
                    $data[] = array_combine($headers, $row);
                }
            }
        }
        
        return $data;
    }
    
    // Save email to database
    private function saveEmailToDatabase($emailData) {
        $db = getDB();
        
        try {
            // Check if email already exists
            $stmt = $db->prepare("SELECT id FROM email_automation WHERE email_uid = ?");
            $stmt->execute([$emailData['uid']]);
            if ($stmt->fetch()) {
                return ['success' => true, 'message' => 'Email already processed', 'existing' => true];
            }
            
            // Insert email
            $stmt = $db->prepare("INSERT INTO email_automation (email_uid, subject, from_address, from_name, to_address, date_received, body_text, body_html, is_processed) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)");
            $stmt->execute([
                $emailData['uid'],
                $emailData['subject'],
                $emailData['from_email'],
                $emailData['from'],
                $emailData['to'],
                $emailData['date'],
                $emailData['body_text'],
                $emailData['body_html']
            ]);
            
            $emailId = $db->lastInsertId();
            
            // Save attachments
            foreach ($emailData['attachments'] as $attachment) {
                $excelDataJson = isset($attachment['excel_data']) ? json_encode($attachment['excel_data']) : null;
                
                $stmt = $db->prepare("INSERT INTO email_attachments (email_id, filename, content_type, size, file_path, excel_data, is_coupon_file) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([
                    $emailId,
                    $attachment['filename'],
                    $attachment['content_type'],
                    $attachment['size'],
                    $attachment['file_path'] ?? null,
                    $excelDataJson,
                    $this->isExcelFile($attachment['filename']) ? 1 : 0
                ]);
            }
            
            return ['success' => true, 'email_id' => $emailId, 'attachments_count' => count($emailData['attachments'])];
            
        } catch (Exception $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
}

// Helper function to run automation
function runEmailAutomation($options = []) {
    $service = new EmailAutomationService();
    
    $limit = $options['limit'] ?? 50;
    $senderEmail = $options['sender_email'] ?? null;
    $attachmentsOnly = $options['attachments_only'] ?? true;
    
    if ($senderEmail) {
        return $service->fetchEmailsFromSender($senderEmail, $limit);
    } elseif ($attachmentsOnly) {
        return $service->fetchEmailsWithAttachments($limit);
    } else {
        return $service->fetchUnreadEmails($limit);
    }
}
