<?php
// Email helper
require_once __DIR__ . '/db.php';

function fetchEmails($limit = 10) {
    global $email_config;
    $mailbox = $email_config['imap_host'];
    $username = $email_config['imap_user'];
    $password = $email_config['imap_password'];
    $inbox = @imap_open($mailbox, $username, $password);
    if (!$inbox) return [];
    $emails = imap_search($inbox, 'UNSEEN', SE_UID);
    if (!$emails) { imap_close($inbox); return []; }
    rsort($emails);
    $results = [];
    $count = 0;
    foreach ($emails as $emailUid) {
        if ($count >= $limit) break;
        $overview = imap_fetch_overview($inbox, $emailUid, FT_UID);
        $body = imap_body($inbox, $emailUid, FT_UID | FT_PEEK);
        $results[] = ['uid' => $emailUid, 'subject' => $overview[0]->subject ?? '', 'from' => $overview[0]->from ?? '', 'date' => $overview[0]->date ?? '', 'body' => $body];
        $count++;
    }
    imap_close($inbox);
    return $results;
}

function processEmailAttachments($emailUid) {
    global $email_config;
    if (empty($emailUid)) jsonResponse(['success' => false, 'message' => 'Email ID required'], 400);
    $mailbox = $email_config['imap_host'];
    $username = $email_config['imap_user'];
    $password = $email_config['imap_password'];
    $inbox = @imap_open($mailbox, $username, $password);
    if (!$inbox) jsonResponse(['success' => false, 'message' => 'IMAP connection failed'], 500);
    $overview = imap_fetch_overview($inbox, $emailUid, FT_UID);
    $body = imap_body($inbox, $emailUid, FT_UID | FT_PEEK);
    $userId = getCurrentUserId();
    $emailId = saveEmailMetadata($emailUid, $overview[0]->subject ?? '', $overview[0]->from ?? '', $overview[0]->to ?? '', date('Y-m-d H:i:s'), $body, $userId, null);
    $structure = imap_fetchstructure($inbox, $emailUid, FT_UID);
    $attachments = [];
    if (isset($structure->parts)) {
        foreach ($structure->parts as $partNum => $part) {
            if (($part->disposition ?? '') === 'ATTACHMENT') {
                $filename = $part->dparameters[0]->value ?? 'attachment';
                $data = imap_fetchbody($inbox, $emailUid, $partNum + 1, FT_UID);
                if ($part->encoding == 4) $data = base64_decode($data);
                $uploadDir = __DIR__ . '/attachments/';
                if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);
                $filePath = $uploadDir . 'email_' . $emailId . '_' . $filename;
                file_put_contents($filePath, $data);
                $attachments[] = ['filename' => $filename, 'path' => $filePath];
            }
        }
    }
    imap_close($inbox);
    jsonResponse(['success' => true, 'email_id' => $emailId, 'attachments' => $attachments]);
}

function uploadExcelFile() {
    if (!isset($_FILES['file'])) jsonResponse(['success' => false, 'message' => 'No file'], 400);
    $file = $_FILES['file'];
    $uploadDir = __DIR__ . '/uploads/';
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);
    $filename = time() . '_' . basename($file['name']);
    $targetPath = $uploadDir . $filename;
    if (move_uploaded_file($file['tmp_name'], $targetPath)) {
        jsonResponse(['success' => true, 'filename' => $filename, 'message' => 'File uploaded']);
    } else {
        jsonResponse(['success' => false, 'message' => 'Upload failed'], 500);
    }
}

function testImapConnection() {
    global $email_config;
    $mailbox = $email_config['imap_host'];
    $username = $email_config['imap_user'];
    $password = $email_config['imap_password'];
    $inbox = @imap_open($mailbox, $username, $password);
    if ($inbox) {
        imap_close($inbox);
        return true;
    }
    return false;
}
